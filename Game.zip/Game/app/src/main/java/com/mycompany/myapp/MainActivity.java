package com.mycompany.myapp;


import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;




public class MainActivity extends Activity implements View.OnClickListener
{
	 private Button btn1,btn2,razrab,exit;
	 
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {  
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_activity);
				mode();
				btn1 = (Button) findViewById(R.id.btnAndroid);
				btn1.setOnClickListener(this);
				btn2 = (Button) findViewById(R.id.startTwoGame);
				btn2.setOnClickListener(this);
				razrab = (Button) findViewById(R.id.razrab);
				razrab.setOnClickListener(this);
				exit = (Button) findViewById(R.id.exit);
				exit.setOnClickListener(this);
		}

		@Override
		public void onClick(View v)
		{
			 switch(v.getId()){
					
					   case R.id.btnAndroid:
					   Intent intent = new Intent(MainActivity.this,ActivityForAndroid.class); 
					   startActivity(intent);
						 MediaPlayer mp = MediaPlayer.create(MainActivity.this,R.raw.click_sound);
						 mp.start();
				     break;	
						 
				   	 case R.id.startTwoGame:
						 Intent intent1 = new Intent(MainActivity.this,ActivityForTwoPlayer.class); 
						 startActivity(intent1);
						 MediaPlayer mp1 = MediaPlayer.create(MainActivity.this,R.raw.click_sound);
						 mp1.start();
						 break;		
						 
						 case R.id.razrab:							
						 startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("http://vk.com/programmer110")));		
						 MediaPlayer mp2 = MediaPlayer.create(MainActivity.this,R.raw.click_sound);
						 mp2.start();
						 break;				
						 
					 	 case R.id.exit:
						 MediaPlayer mp3 = MediaPlayer.create(MainActivity.this,R.raw.click_sound);
						 mp3.start();
						 finish();
						 break;
			 }	 
		}
	 
	 public void mode(){	 
			 getActionBar().hide();
			 getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	 }
	 
	 
}

