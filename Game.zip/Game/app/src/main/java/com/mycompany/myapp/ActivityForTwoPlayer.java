package com.mycompany.myapp;


import android.app.*;
import android.graphics.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.util.*;

public class ActivityForTwoPlayer extends Activity
{
	 private ImageView imageViewB,imageView1P;
	 private TextView tView1,tView2,tView3,gameName; 
	 private int androidTrow;
	 private int playerTrow;

	 Random r; 
	 int androidPoints = 0;
	 int playerPoints = 0;

	 @Override
	 protected void onCreate(Bundle savedInstanceState)
	 {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.multi_player);
			mode();
			imageViewB = (ImageView) findViewById(R.id.imageViewB);
			imageView1P = (ImageView) findViewById(R.id.imageView1P);

			tView1 = (TextView) findViewById(R.id.tView1);
			tView2 = (TextView) findViewById(R.id.tView2);
			tView3 = (TextView) findViewById(R.id.tView3);
			gameName = (TextView) findViewById(R.id.gameName);

			tView1.setTextColor(Color.WHITE);
			tView2.setTextColor(Color.WHITE);
			tView3.setTextColor(Color.WHITE);
			tView3.setTextColor(Color.WHITE);
			r = new Random();	

			imageViewB.setOnClickListener(new View.OnClickListener(){
						@Override
						public void onClick(View v)
						{
							 MediaPlayer mp = MediaPlayer.create(ActivityForTwoPlayer.this, R.raw.click_sound_bone);
							 mp.start();
							 androidTrow = r.nextInt(6) + 1;
							 playerTrow = r.nextInt(6) + 1;
							 int color_text_game = r.nextInt(4) + 1;

							 setImageAndroid(androidTrow);

							 if (androidTrow > playerTrow)
							 {
									androidPoints++;
							 }

							 tView1.setText("Player2: " + androidPoints);
							 setColorText(color_text_game);

							 Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
							 imageViewB.startAnimation(rotate);

						}			
				 });

			imageView1P.setOnClickListener(new View.OnClickListener(){
						@Override
						public void onClick(View v)
						{
							 MediaPlayer mp = MediaPlayer.create(ActivityForTwoPlayer.this, R.raw.click_sound_bone);
							 mp.start();
							 androidTrow = r.nextInt(6) + 1;
							 playerTrow = r.nextInt(6) + 1;
							 int color_text_game = r.nextInt(4) + 1;
							 setImagePlayer(playerTrow);

							 if (playerTrow > androidTrow)
							 {
									playerPoints++;
							 }
							 tView2.setText("You: " + playerPoints);
							 setColorText(color_text_game);

							 Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);

							 imageView1P.startAnimation(rotate);

						}			
				 });


	 }




	 public void setImageAndroid(int num)
	 {

			switch (num)
			{

				 case 1:
						imageViewB.setImageResource(R.drawable.i_1);
						break;

				 case 2:
						imageViewB.setImageResource(R.drawable.i_2);
						break;

				 case 3:
						imageViewB.setImageResource(R.drawable.i_3);
						break;

				 case 4:
						imageViewB.setImageResource(R.drawable.i_4);
						break;

				 case 5:
						imageViewB.setImageResource(R.drawable.i_5);
						break;

				 case 6:
						imageViewB.setImageResource(R.drawable.i_6);
						break;
			}

	 }	

	 public void setImagePlayer(int num)
	 {

			switch (num)
			{
				 case 1:
						imageView1P.setImageResource(R.drawable.i_1);
						break;
				 case 2:
						imageView1P.setImageResource(R.drawable.i_2);
						break;

				 case 3:
						imageView1P.setImageResource(R.drawable.i_3);
						break;

				 case 4:
						imageView1P.setImageResource(R.drawable.i_4);
						break;

				 case 5:
						imageView1P.setImageResource(R.drawable.i_5);
						break;

				 case 6:
						imageView1P.setImageResource(R.drawable.i_6);
						break;
			}

	 }	

	 public void setColorText(int num)
	 {
			switch (num)
			{

				 case 1:
						gameName.setTextColor(Color.BLUE);

						break;
				 case 2:
						gameName.setTextColor(Color.GREEN);
						break;


				 case 3:
						gameName.setTextColor(Color.WHITE);
						break;


				 case 4:
						gameName.setTextColor(Color.GRAY);
						break;
			}
	 }


	 public void mode()
	 {
			getActionBar().hide();
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
	 }
}






